import numpy as np
import matplotlib.pyplot as plt

def polarize(p, N):
    if N == 1:
        return [1-p]
    else:
        polarized_channels = []
        polarized_channels += polarize(2 * p - p ** 2, N // 2)
        polarized_channels += polarize(p*p, N // 2)
        return polarized_channels

def plot_polarization(p, N):
    channels = polarize(p, N)
    channel_numbers = np.arange(0, N)  # Adjust x-axis values
    
    plt.scatter(channel_numbers, channels, marker='o', color='blue')
    plt.xlabel('Channel Number')
    plt.ylabel('Channel Polarization')
    plt.title(f'Channel Polarization vs. Channel Number (BEC) for n={np.log2(N)}')
    plt.grid(True)
    plt.show()
    

def plot_sorted_polarization(p,N):
    channels = polarize(p, N)
    channel_numbers = np.arange(0, N)  # Adjust x-axis values
    channels.sort()
    plt.figure(2)
    plt.scatter(channel_numbers, channels, marker='o', color='blue')
    plt.xlabel('Channel Number')
    plt.ylabel('Channel Polarization')
    plt.title(f'Channel Polarization vs. Channel Number (BEC) for n={np.log2(N)}')
    plt.grid(True)
    plt.show()

# Parameters
p = 0.5

# Plotting for different values of n
n_values = [4, 10, 20]
for n in n_values:
    N = 2 ** n
    plot_sorted_polarization(p, N)

# n_values = 10
# plot_polarization(p,2**n_values)

